/**
 * @prettier
 */
const idnHostnameGenerator = () => "실례.com"

export default idnHostnameGenerator
